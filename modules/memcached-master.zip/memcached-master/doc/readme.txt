To build the documentation you need xml2rfc ( http://xml.resource.org/ ).
